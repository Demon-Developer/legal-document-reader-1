from typing import Tuple, List, Dict
import re
import textwrap

# Lightweight rule-based simplifier (no external ML needed).
REPLACEMENTS = {
    "hereinafter": "from now on",
    "herein": "in this document",
    "aforementioned": "mentioned earlier",
    "whereas": "because",
    "pursuant to": "under",
    "thereof": "of that",
    "therein": "in that",
    "hereto": "to this",
    "henceforth": "from now on",
    "indemnify": "pay for losses and damages",
    "indemnification": "payment for losses and damages",
    "liability": "legal responsibility",
    "limitation of liability": "limit on legal responsibility",
    "confidential information": "private information",
    "arbitration": "private dispute process",
    "force majeure": "events beyond control",
    "non-disparagement": "no negative public comments",
    "automatic renewal": "auto-renewal",
    "assign": "transfer",
    "terminate": "end",
    "terminated": "ended",
    "waive": "give up",
    "warranty": "guarantee",
}

def _normalize_whitespace(text: str) -> str:
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()

def _split_sentences(text: str) -> List[str]:
    # Simple sentence splitter (handles ; and . and : with space)
    text = re.sub(r"([;:])", r".", text)
    # protect abbreviations
    sentences = re.split(r"(?<=[.!?])\s+(?=[A-Z0-9])", text)
    return [s.strip() for s in sentences if s.strip()]

def simplify_text(document: str) -> Tuple[str, List[Dict]]:
    """
    Returns simplified text and a mapping list of {original, simplified}.
    """
    document = _normalize_whitespace(document)
    sentences = _split_sentences(document)
    mapping = []
    simplified_sentences = []
    for s in sentences:
        orig = s
        simp = s
        # Lowercase map but keep case by replacing case-insensitively
        for k, v in REPLACEMENTS.items():
            simp = re.sub(rf"(?i)\b{k}\b", v, simp)
        # Shorten overly long sentences
        if len(simp) > 240:
            # insert breaks at commas
            parts = [p.strip() for p in re.split(r",\s*", simp)]
            # keep to ~2 clauses
            if len(parts) > 2:
                simp = "; ".join(parts[:2]) + ". (shortened)"
        # Make language active voice-ish
        simp = re.sub(r"(?i)\bshall\b", "will", simp)
        simp = re.sub(r"(?i)\bprior to\b", "before", simp)
        simp = re.sub(r"(?i)\bsubsequent to\b", "after", simp)
        simp = re.sub(r"(?i)\butilize\b", "use", simp)
        simplified_sentences.append(simp)
        if orig != simp:
            mapping.append({"original": orig, "simplified": simp})
    simplified = " ".join(simplified_sentences)
    # Wrap to readable width
    simplified = textwrap.fill(simplified, width=100)
    return simplified, mapping
