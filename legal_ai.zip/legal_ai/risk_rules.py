import re
from typing import List, Dict

RISK_PATTERNS = [
    ("Auto-Renewal", r"(auto[- ]?renew|automatic renewal)", "Medium", "Auto-renews unless you cancel."),
    ("Arbitration Only", r"(binding )?arbitration", "High", "Disputes must go to private arbitration, not court."),
    ("No Class Actions", r"(class action|class[- ]?arbitration) waiver", "High", "Gives up the right to join class actions."),
    ("Unilateral Changes", r"(we|company) may (modify|change) (these )?terms (at any time|without notice)", "High", "Company can change terms anytime."),
    ("Limitation of Liability", r"limitation of liability|liability is limited|no liability for", "High", "Caps the company's responsibility for damages."),
    ("Indemnity", r"indemnif(y|ication)", "Medium", "You pay the company for certain losses."),
    ("Data Sharing", r"(share|sell) (your )?data|third[- ]?party (partners|advertisers)", "Medium", "Your data may be shared or sold."),
    ("Early Termination", r"terminate (at any time|for any reason|without cause)", "Medium", "They can end the agreement at will."),
    ("Late Fees", r"late fee|penalt(y|ies) for late", "Low", "Extra charges if you pay late."),
    ("Assignment Without Consent", r"(assign|transfer) (this )?(agreement|contract) (without your consent|at its discretion)", "Low", "They can transfer the contract to someone else."),
    ("Governing Law Far Away", r"governing law.*(delaware|california|new york)", "Low", "Disputes will be decided under a specific state's law."),
]

def analyze_risks(document: str) -> List[Dict]:
    findings = []
    for name, pattern, severity, why in RISK_PATTERNS:
        for m in re.finditer(pattern, document, flags=re.IGNORECASE | re.MULTILINE | re.DOTALL):
            start = max(0, m.start() - 80)
            end = min(len(document), m.end() + 80)
            snippet = document[start:end].strip().replace("\n", " ")
            findings.append({
                "clause": name,
                "severity": severity,
                "reason": why,
                "match": m.group(0),
                "context": snippet
            })
    # sort by severity weight
    weight = {"High": 3, "Medium": 2, "Low": 1}
    findings.sort(key=lambda x: -weight.get(x["severity"], 0))
    return findings
