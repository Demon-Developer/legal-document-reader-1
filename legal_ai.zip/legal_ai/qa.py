from typing import Tuple, List
import re
import math
from collections import Counter

def _sentences(text: str) -> List[str]:
    text = re.sub(r"([;:])", ".", text)
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]

def _tokenize(text: str) -> List[str]:
    return [t.lower() for t in re.findall(r"[a-zA-Z0-9']+", text)]

def _bow_vector(tokens: List[str]) -> Counter:
    return Counter(tokens)

def _cosine(a: Counter, b: Counter) -> float:
    if not a or not b:
        return 0.0
    inter = set(a) & set(b)
    num = sum(a[t] * b[t] for t in inter)
    den = math.sqrt(sum(v*v for v in a.values())) * math.sqrt(sum(v*v for v in b.values()))
    return (num / den) if den else 0.0

def _simplify_answer(text: str) -> str:
    # Shorten long sentences for the answer
    if len(text) > 240:
        parts = text.split(",")
        text = ", ".join(parts[:2]) + "..."
    return text

def answer_question(document: str, question: str) -> Tuple[str, List[str]]:
    sents = _sentences(document)
    qvec = _bow_vector(_tokenize(question))
    scored = []
    for s in sents:
        vec = _bow_vector(_tokenize(s))
        scored.append((s, _cosine(vec, qvec)))
    scored.sort(key=lambda x: -x[1])
    evidence = [s for s, sc in scored[:3] if sc > 0]
    if not evidence:
        return ("I couldn't find a clear answer in the document. Please try rephrasing the question.", [])
    # Compose a short answer
    best = evidence[0]
    answer = _simplify_answer(best)
    return (answer, evidence)
